package com.tcc.estoqueinteligente.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.tcc.estoqueinteligente.data.model.Entrada
import com.tcc.estoqueinteligente.data.model.Fornecedor
import com.tcc.estoqueinteligente.data.model.Lote
import com.tcc.estoqueinteligente.data.model.Produto

@Database(
    entities = [Produto::class, Fornecedor::class, Entrada::class, Lote::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun produtoDao(): ProdutoDao
    abstract fun fornecedorDao(): FornecedorDao
    abstract fun entradaDao(): EntradaDao
    abstract fun loteDao(): LoteDao

    companion object {
        @Volatile
        private var instancia: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "estoque_inteligente.db"
                ).build().also { instancia = it }
            }
        }
    }
}
