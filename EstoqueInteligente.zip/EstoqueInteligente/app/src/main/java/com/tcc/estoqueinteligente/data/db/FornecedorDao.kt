package com.tcc.estoqueinteligente.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.tcc.estoqueinteligente.data.model.Fornecedor

@Dao
interface FornecedorDao {

    @Query("SELECT * FROM fornecedores WHERE cnpj = :cnpj LIMIT 1")
    suspend fun buscarPorCnpj(cnpj: String): Fornecedor?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun inserir(fornecedor: Fornecedor): Long
}
