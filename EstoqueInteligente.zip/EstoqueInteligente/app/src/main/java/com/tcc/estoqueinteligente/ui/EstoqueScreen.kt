package com.tcc.estoqueinteligente.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tcc.estoqueinteligente.data.model.Produto

@Composable
fun EstoqueScreen(produtos: List<Produto>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Estoque", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        if (produtos.isEmpty()) {
            Text("Nenhum produto cadastrado ainda. Leia uma NF-e para começar.")
            return@Column
        }

        LazyColumn {
            items(produtos, key = { it.id }) { produto ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(produto.nome, style = MaterialTheme.typography.titleMedium)
                        Text("Quantidade: ${produto.estoqueAtual} ${produto.unidade}")
                        Text("Estoque mínimo: ${produto.estoqueMinimo} ${produto.unidade}")
                        if (produto.estoqueAtual <= produto.estoqueMinimo) {
                            Text(
                                "⚠ Estoque baixo",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}
