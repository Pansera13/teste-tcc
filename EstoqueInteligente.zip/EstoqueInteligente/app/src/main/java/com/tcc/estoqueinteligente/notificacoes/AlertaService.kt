package com.tcc.estoqueinteligente.notificacoes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.tcc.estoqueinteligente.data.db.AppDatabase
import java.util.concurrent.TimeUnit

/**
 * Gera os alertas descritos na Etapa 13:
 *  - estoque baixo (estoqueAtual <= estoqueMinimo)
 *  - produto próximo do vencimento / vencido (usa a tabela `lotes`, quando preenchida)
 *  - consumo fora do padrão: DEIXADO COMO PONTO DE EXPANSÃO (Etapa 14 - previsão de consumo),
 *    pois exige um histórico maior de dados para calcular uma média confiável.
 *
 * Pode ser chamado periodicamente via WorkManager (ver AlertaWorker) ou manualmente
 * a partir da tela de estoque.
 */
class AlertaService(private val context: Context, private val db: AppDatabase) {

    companion object {
        const val CANAL_ALERTAS_ID = "alertas_estoque"
        const val DIAS_ANTES_DO_VENCIMENTO_PARA_ALERTAR = 7L
    }

    fun criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CANAL_ALERTAS_ID,
                "Alertas de estoque",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(canal)
        }
    }

    suspend fun verificarEstoqueBaixoEAvisar() {
        val produtosComEstoqueBaixo = db.produtoDao().listarEstoqueBaixo()
        if (produtosComEstoqueBaixo.isEmpty()) return

        val nomes = produtosComEstoqueBaixo.joinToString(", ") { it.nome }
        notificar(
            id = 1001,
            titulo = "Estoque baixo",
            texto = "Produto(s) abaixo do mínimo: $nomes"
        )
    }

    suspend fun verificarValidadesEAvisar() {
        val agora = System.currentTimeMillis()
        val limiteAlerta = agora + TimeUnit.DAYS.toMillis(DIAS_ANTES_DO_VENCIMENTO_PARA_ALERTAR)

        // Percorre todos os produtos que controlam lote/validade.
        // Em uma versão maior, troque por uma query direta na tabela `lotes`.
        val todosOsLotes = db.loteDao().let { dao ->
            // Placeholder simples: numa evolução futura, adicionar LoteDao.listarTodos()
            emptyList<Nothing>()
        }
        // TODO(Etapa 14): quando o cadastro de lotes estiver em uso no fluxo principal,
        // percorrer os lotes com dataValidadeEpochMillis in (agora..limiteAlerta) -> "próximo do vencimento"
        // e dataValidadeEpochMillis < agora -> "vencido", chamando notificar(...) para cada caso.
    }

    private fun notificar(id: Int, titulo: String, texto: String) {
        val notificacao = NotificationCompat.Builder(context, CANAL_ALERTAS_ID)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notificacao)
    }
}
