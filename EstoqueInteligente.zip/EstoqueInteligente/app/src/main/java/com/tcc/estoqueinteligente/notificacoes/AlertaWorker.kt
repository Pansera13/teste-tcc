package com.tcc.estoqueinteligente.notificacoes

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.tcc.estoqueinteligente.data.db.AppDatabase

/**
 * Roda periodicamente em segundo plano (agendado em MainActivity/App) para
 * verificar estoque baixo e validades próximas, disparando notificações locais.
 */
class AlertaWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.getInstance(applicationContext)
        val alertaService = AlertaService(applicationContext, db)
        alertaService.criarCanalNotificacao()
        alertaService.verificarEstoqueBaixoEAvisar()
        alertaService.verificarValidadesEAvisar()
        return Result.success()
    }
}
