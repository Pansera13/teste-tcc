package com.tcc.estoqueinteligente.nfe

import android.util.Xml
import com.tcc.estoqueinteligente.data.model.NotaFiscal
import com.tcc.estoqueinteligente.data.model.ProdutoNFe
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Responsável por transformar um XML de NF-e (padrão SEFAZ, tag raiz <nfeProc> ou <NFe>)
 * em um objeto NotaFiscal utilizável pelo restante do app.
 *
 * Esta classe NÃO faz nenhuma chamada de rede. Ela apenas interpreta um XML
 * que já foi obtido em algum lugar (arquivo local na Etapa 1, ou futuramente
 * via NFeService na Etapa 3).
 *
 * Estrutura simplificada do XML de NF-e (tags relevantes):
 * <NFe>
 *   <infNFe Id="NFe4425...">          <- aqui vem a chave de acesso (44 dígitos após o prefixo "NFe")
 *     <ide><nNF>..</nNF><serie>..</serie><dhEmi>..</dhEmi></ide>
 *     <emit><xNome>..</xNome><CNPJ>..</CNPJ></emit>
 *     <det nItem="1">
 *       <prod>
 *         <cProd>..</cProd><cEAN>..</cEAN><xProd>..</xProd><NCM>..</NCM>
 *         <uCom>..</uCom><qCom>..</qCom><vUnCom>..</vUnCom><vProd>..</vProd>
 *       </prod>
 *     </det>
 *   </infNFe>
 * </NFe>
 */
class NFeXmlParser {

    fun parse(inputStream: InputStream): NotaFiscal {
        val parser: XmlPullParser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(inputStream, null)

        var chaveAcesso = ""
        var numero = ""
        var serie = ""
        var dataEmissaoTexto = ""
        var fornecedorNome = ""
        var fornecedorCnpj = ""
        val produtos = mutableListOf<ProdutoNFe>()

        var dentroDeEmit = false
        var dentroDeProd = false

        var cProd = ""
        var cEAN = ""
        var xProd = ""
        var ncm = ""
        var uCom = ""
        var qCom = 0.0
        var vUnCom = 0.0
        var vProd = 0.0

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "infNFe" -> {
                            val id = parser.getAttributeValue(null, "Id") ?: ""
                            // O atributo Id vem como "NFe" + 44 dígitos. Extraímos só os números.
                            chaveAcesso = id.filter { it.isDigit() }
                        }
                        "emit" -> dentroDeEmit = true
                        "det" -> dentroDeProd = true
                        "nNF" -> numero = readText(parser)
                        "serie" -> serie = readText(parser)
                        "dhEmi" -> dataEmissaoTexto = readText(parser)
                        "dEmi" -> if (dataEmissaoTexto.isEmpty()) dataEmissaoTexto = readText(parser)
                        "xNome" -> if (dentroDeEmit) fornecedorNome = readText(parser)
                        "CNPJ" -> if (dentroDeEmit) fornecedorCnpj = readText(parser)
                        "cProd" -> if (dentroDeProd) cProd = readText(parser)
                        "cEAN" -> if (dentroDeProd) cEAN = readText(parser)
                        "xProd" -> if (dentroDeProd) xProd = readText(parser)
                        "NCM" -> if (dentroDeProd) ncm = readText(parser)
                        "uCom" -> if (dentroDeProd) uCom = readText(parser)
                        "qCom" -> if (dentroDeProd) qCom = readText(parser).toDoubleOrNull() ?: 0.0
                        "vUnCom" -> if (dentroDeProd) vUnCom = readText(parser).toDoubleOrNull() ?: 0.0
                        "vProd" -> if (dentroDeProd) vProd = readText(parser).toDoubleOrNull() ?: 0.0
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "emit" -> dentroDeEmit = false
                        "det" -> {
                            dentroDeProd = false
                            produtos.add(
                                ProdutoNFe(
                                    codigoProdutoFornecedor = cProd,
                                    codigoBarras = cEAN.takeIf { it.isNotBlank() && it != "SEM GTIN" },
                                    descricao = xProd,
                                    ncm = ncm.ifBlank { null },
                                    unidadeComercial = uCom,
                                    quantidade = qCom,
                                    valorUnitario = vUnCom,
                                    valorTotal = vProd
                                )
                            )
                            // reseta acumuladores do item para o próximo <det>
                            cProd = ""; cEAN = ""; xProd = ""; ncm = ""; uCom = ""
                            qCom = 0.0; vUnCom = 0.0; vProd = 0.0
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        return NotaFiscal(
            numero = numero,
            serie = serie,
            chaveAcesso = chaveAcesso,
            fornecedorNome = fornecedorNome,
            fornecedorCnpj = fornecedorCnpj,
            dataEmissaoEpochMillis = parseDataEmissao(dataEmissaoTexto),
            produtos = produtos
        )
    }

    private fun readText(parser: XmlPullParser): String {
        var resultado = ""
        if (parser.next() == XmlPullParser.TEXT) {
            resultado = parser.text
            parser.nextTag()
        }
        return resultado.trim()
    }

    /** dhEmi vem como "2024-05-10T14:33:00-03:00"; dEmi (layouts antigos) vem como "2024-05-10". */
    private fun parseDataEmissao(texto: String): Long {
        if (texto.isBlank()) return System.currentTimeMillis()
        return try {
            val formato = if (texto.contains("T")) {
                SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.getDefault())
            } else {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            }
            formato.parse(texto)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }
}
