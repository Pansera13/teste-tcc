package com.tcc.estoqueinteligente.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Representa uma entrada de estoque (Etapa 12 - Histórico de movimentações).
 * Cada linha de produto confirmado de uma NF-e vira uma Entrada.
 */
@Entity(tableName = "entradas")
data class Entrada(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val produtoId: Long,
    val quantidade: Double,
    val precoUnitario: Double,
    val dataHoraEpochMillis: Long,
    val numeroNFe: String,
    val chaveNFe: String
)
