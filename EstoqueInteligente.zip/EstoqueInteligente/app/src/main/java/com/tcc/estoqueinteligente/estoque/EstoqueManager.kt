package com.tcc.estoqueinteligente.estoque

import com.tcc.estoqueinteligente.data.db.AppDatabase
import com.tcc.estoqueinteligente.data.model.Entrada
import com.tcc.estoqueinteligente.data.model.Fornecedor
import com.tcc.estoqueinteligente.data.model.NotaFiscal
import com.tcc.estoqueinteligente.data.model.Produto

/**
 * Regra de negócio central: quando o usuário confirma a tela de conferência (Etapa 9/10),
 * este componente:
 *   1. garante que o fornecedor existe;
 *   2. para cada produto da NF-e, encontra o produto correspondente no estoque
 *      (por código de barras, ou cria um novo se ainda não existir);
 *   3. soma a quantidade lida ao estoque atual (ver exemplo do enunciado:
 *      10 + 20 = 30 unidades);
 *   4. grava um registro de Entrada no histórico de movimentações (Etapa 12).
 */
class EstoqueManager(private val db: AppDatabase) {

    suspend fun confirmarEntradaNFe(notaFiscal: NotaFiscal) {
        // 1) Garante o fornecedor
        var fornecedor: Fornecedor? = db.fornecedorDao().buscarPorCnpj(notaFiscal.fornecedorCnpj)
        if (fornecedor == null) {
            val novoId = db.fornecedorDao().inserir(
                Fornecedor(nome = notaFiscal.fornecedorNome, cnpj = notaFiscal.fornecedorCnpj)
            )
            fornecedor = Fornecedor(id = novoId, nome = notaFiscal.fornecedorNome, cnpj = notaFiscal.fornecedorCnpj)
        }

        // 2) Evita duplicar a mesma NF-e caso o usuário confirme duas vezes
        val jaLancada = db.entradaDao().buscarPorChaveNFe(notaFiscal.chaveAcesso)
        if (jaLancada != null) return

        // 3) Para cada produto da nota, localiza ou cria o produto no estoque, e soma a quantidade
        for (item in notaFiscal.produtos) {
            var produto: Produto? = item.codigoBarras?.let { db.produtoDao().buscarPorCodigoBarras(it) }
                ?: db.produtoDao().buscarPorNomeAproximado(item.descricao)

            if (produto == null) {
                val novoId = db.produtoDao().inserir(
                    Produto(
                        nome = item.descricao,
                        codigoBarras = item.codigoBarras,
                        codigoProdutoNFe = item.codigoProdutoFornecedor,
                        ncm = item.ncm,
                        unidade = item.unidadeComercial,
                        estoqueAtual = 0.0
                    )
                )
                produto = db.produtoDao().buscarPorCodigoBarras(item.codigoBarras ?: "")
                    ?: Produto(id = novoId, nome = item.descricao, unidade = item.unidadeComercial, estoqueAtual = 0.0)
            }

            val estoqueAtualizado = produto.copy(estoqueAtual = produto.estoqueAtual + item.quantidade)
            db.produtoDao().atualizar(estoqueAtualizado)

            // 4) Histórico de movimentação (Etapa 12)
            db.entradaDao().inserir(
                Entrada(
                    produtoId = estoqueAtualizado.id,
                    quantidade = item.quantidade,
                    precoUnitario = item.valorUnitario,
                    dataHoraEpochMillis = System.currentTimeMillis(),
                    numeroNFe = notaFiscal.numero,
                    chaveNFe = notaFiscal.chaveAcesso
                )
            )
        }
    }
}
