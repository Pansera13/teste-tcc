package com.tcc.estoqueinteligente.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fornecedores")
data class Fornecedor(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nome: String,
    val cnpj: String
)
