package com.tcc.estoqueinteligente.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Representa um produto no estoque.
 * Campos conforme especificação da Etapa 11 (Tela de Estoque) e da estrutura de banco de dados.
 */
@Entity(tableName = "produtos")
data class Produto(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val nome: String,
    val codigoBarras: String? = null,
    val codigoProdutoNFe: String? = null, // código interno usado pelo fornecedor na NF-e
    val ncm: String? = null,
    val unidade: String, // ex: "UN", "KG", "L"

    val estoqueAtual: Double = 0.0,
    val estoqueMinimo: Double = 0.0,
    val estoqueMaximo: Double? = null,

    // Preparado para a Etapa 14 (controle de lote/validade), mesmo que ainda não usado ativamente
    val controlaLote: Boolean = false,
    val controlaValidade: Boolean = false
)
