package com.tcc.estoqueinteligente.data.db

import androidx.room.*
import com.tcc.estoqueinteligente.data.model.Produto
import kotlinx.coroutines.flow.Flow

@Dao
interface ProdutoDao {

    @Query("SELECT * FROM produtos ORDER BY nome ASC")
    fun observarTodos(): Flow<List<Produto>>

    @Query("SELECT * FROM produtos WHERE codigoBarras = :codigoBarras LIMIT 1")
    suspend fun buscarPorCodigoBarras(codigoBarras: String): Produto?

    @Query("SELECT * FROM produtos WHERE nome LIKE '%' || :nome || '%' LIMIT 1")
    suspend fun buscarPorNomeAproximado(nome: String): Produto?

    @Query("SELECT * FROM produtos WHERE estoqueAtual <= estoqueMinimo")
    suspend fun listarEstoqueBaixo(): List<Produto>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun inserir(produto: Produto): Long

    @Update
    suspend fun atualizar(produto: Produto)
}
