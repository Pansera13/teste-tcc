package com.tcc.estoqueinteligente

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tcc.estoqueinteligente.data.db.AppDatabase
import com.tcc.estoqueinteligente.data.model.NotaFiscal
import com.tcc.estoqueinteligente.estoque.EstoqueManager
import com.tcc.estoqueinteligente.nfe.NFeServiceProvider
import com.tcc.estoqueinteligente.nfe.ResultadoNFe
import com.tcc.estoqueinteligente.scanner.LeitorCodigoScreen
import com.tcc.estoqueinteligente.ui.ConferenciaScreen
import com.tcc.estoqueinteligente.ui.EstoqueScreen
import com.tcc.estoqueinteligente.ui.HistoricoScreen
import com.tcc.estoqueinteligente.ui.HomeScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    AppNavigation()
                }
            }
        }
    }
}

private const val ROTA_HOME = "home"
private const val ROTA_CAMERA = "camera"
private const val ROTA_CONFERENCIA = "conferencia"
private const val ROTA_ESTOQUE = "estoque"
private const val ROTA_HISTORICO = "historico"

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = androidx.compose.ui.platform.LocalContext.current
    val escopo = rememberCoroutineScope()

    val db = remember { AppDatabase.getInstance(context) }
    val nfeService = remember { NFeServiceProvider.get(context) }
    val estoqueManager = remember { EstoqueManager(db) }

    // Guarda a última NF-e lida, para passar da tela de leitura para a de conferência
    var notaFiscalLida by remember { mutableStateOf<NotaFiscal?>(null) }
    var mensagemErro by remember { mutableStateOf<String?>(null) }

    val seletorDeArquivo = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            escopo.launch {
                when (val resultado = nfeService.obterNotaFiscalPorArquivoLocal(context, uri)) {
                    is ResultadoNFe.Sucesso -> {
                        notaFiscalLida = resultado.notaFiscal
                        navController.navigate(ROTA_CONFERENCIA)
                    }
                    is ResultadoNFe.Erro -> {
                        mensagemErro = resultado.mensagem
                    }
                }
            }
        }
    }

    mensagemErro?.let { erro ->
        AlertDialog(
            onDismissRequest = { mensagemErro = null },
            confirmButton = {
                TextButton(onClick = { mensagemErro = null }) { Text("OK") }
            },
            title = { Text("Não foi possível ler a NF-e") },
            text = { Text(erro) }
        )
    }

    NavHost(navController = navController, startDestination = ROTA_HOME) {

        composable(ROTA_HOME) {
            val produtos by db.produtoDao().observarTodos().collectAsState(initial = emptyList())
            val entradas by db.entradaDao().observarTodas().collectAsState(initial = emptyList())

            HomeScreen(
                onLerViaCameraClick = { navController.navigate(ROTA_CAMERA) },
                onCarregarXmlLocalClick = {
                    seletorDeArquivo.launch(arrayOf("text/xml", "application/xml"))
                },
                onVerEstoqueClick = { navController.navigate(ROTA_ESTOQUE) },
                onVerHistoricoClick = { navController.navigate(ROTA_HISTORICO) }
            )
        }

        composable(ROTA_CAMERA) {
            // Etapa 2/3: leitura da chave via câmera. Como ainda não há API autorizada
            // configurada, ao ler a chave mostramos a mensagem de NFeService explicando
            // que é necessário selecionar o XML manualmente por enquanto.
            LeitorCodigoScreen { chaveLida ->
                escopo.launch {
                    when (val resultado = nfeService.obterNotaFiscalPorChave(chaveLida)) {
                        is ResultadoNFe.Sucesso -> {
                            notaFiscalLida = resultado.notaFiscal
                            navController.navigate(ROTA_CONFERENCIA)
                        }
                        is ResultadoNFe.Erro -> {
                            mensagemErro = "Chave lida: $chaveLida\n\n${resultado.mensagem}"
                            navController.popBackStack()
                        }
                    }
                }
            }
        }

        composable(ROTA_CONFERENCIA) {
            val nota = notaFiscalLida
            if (nota == null) {
                Text("Nenhuma NF-e carregada.", modifier = Modifier.padding(16.dp))
            } else {
                ConferenciaScreen(
                    notaFiscal = nota,
                    onConfirmar = { notaConfirmada ->
                        escopo.launch {
                            estoqueManager.confirmarEntradaNFe(notaConfirmada)
                            notaFiscalLida = null
                            navController.popBackStack(ROTA_HOME, inclusive = false)
                        }
                    },
                    onCancelar = {
                        notaFiscalLida = null
                        navController.popBackStack(ROTA_HOME, inclusive = false)
                    }
                )
            }
        }

        composable(ROTA_ESTOQUE) {
            val produtos by db.produtoDao().observarTodos().collectAsState(initial = emptyList())
            EstoqueScreen(produtos = produtos)
        }

        composable(ROTA_HISTORICO) {
            val entradas by db.entradaDao().observarTodas().collectAsState(initial = emptyList())
            val produtos by db.produtoDao().observarTodos().collectAsState(initial = emptyList())
            HistoricoScreen(
                entradas = entradas,
                nomeDoProduto = { id -> produtos.firstOrNull { it.id == id }?.nome ?: "Produto #$id" }
            )
        }
    }
}
