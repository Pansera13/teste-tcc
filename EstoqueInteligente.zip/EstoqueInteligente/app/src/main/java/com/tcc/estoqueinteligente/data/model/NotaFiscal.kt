package com.tcc.estoqueinteligente.data.model

/**
 * Representa uma NF-e completa já extraída do XML (Etapa 8), antes de virar
 * registros definitivos no banco (isso só acontece quando o usuário confirma, Etapa 10).
 */
data class NotaFiscal(
    val numero: String,
    val serie: String,
    val chaveAcesso: String, // 44 dígitos
    val fornecedorNome: String,
    val fornecedorCnpj: String,
    val dataEmissaoEpochMillis: Long,
    val produtos: List<ProdutoNFe>
)

/**
 * Um item/produto dentro da NF-e, com os campos exigidos na Etapa 8.
 * Os campos "quantidade" e "produtoEditado" são mutáveis (var) porque a tela
 * de conferência (Etapa 9) precisa permitir edição antes da confirmação.
 */
data class ProdutoNFe(
    val codigoProdutoFornecedor: String,
    val codigoBarras: String?,
    var descricao: String,
    val ncm: String?,
    val unidadeComercial: String,
    var quantidade: Double,
    val valorUnitario: Double,
    val valorTotal: Double
)

/** Chave de acesso da NF-e possui exatamente 44 dígitos numéricos (Etapa 6). */
fun validarChaveNFe(chave: String): Boolean {
    val somenteNumeros = chave.filter { it.isDigit() }
    return somenteNumeros.length == 44
}
