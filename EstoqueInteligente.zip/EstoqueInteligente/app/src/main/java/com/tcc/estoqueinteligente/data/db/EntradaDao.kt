package com.tcc.estoqueinteligente.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.tcc.estoqueinteligente.data.model.Entrada
import kotlinx.coroutines.flow.Flow

@Dao
interface EntradaDao {

    @Query("SELECT * FROM entradas ORDER BY dataHoraEpochMillis DESC")
    fun observarTodas(): Flow<List<Entrada>>

    @Query("SELECT * FROM entradas WHERE chaveNFe = :chaveNFe LIMIT 1")
    suspend fun buscarPorChaveNFe(chaveNFe: String): Entrada?

    @Insert
    suspend fun inserir(entrada: Entrada): Long
}
