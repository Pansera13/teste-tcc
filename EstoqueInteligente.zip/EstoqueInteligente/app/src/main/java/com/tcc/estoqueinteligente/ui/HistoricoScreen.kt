package com.tcc.estoqueinteligente.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tcc.estoqueinteligente.data.model.Entrada
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoricoScreen(entradas: List<Entrada>, nomeDoProduto: (Long) -> String) {
    val formatoData = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Histórico de movimentações", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        if (entradas.isEmpty()) {
            Text("Nenhuma movimentação registrada ainda.")
            return@Column
        }

        LazyColumn {
            items(entradas, key = { it.id }) { entrada ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("ENTRADA", style = MaterialTheme.typography.labelLarge)
                        Text(nomeDoProduto(entrada.produtoId))
                        Text("+${entrada.quantidade} unidades")
                        Text("NF-e #${entrada.numeroNFe}")
                        Text("Data: ${formatoData.format(Date(entrada.dataHoraEpochMillis))}")
                    }
                }
            }
        }
    }
}
