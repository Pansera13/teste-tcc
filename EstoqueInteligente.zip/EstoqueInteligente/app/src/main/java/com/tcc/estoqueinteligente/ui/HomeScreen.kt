package com.tcc.estoqueinteligente.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Tela inicial (Etapa 2 da especificação: botão "Ler NF-e").
 *
 * onLerViaCameraClick -> abre a câmera para ler o QR Code/código de barras (Etapa 2/3)
 * onCarregarXmlLocalClick -> abre o seletor de arquivos para escolher um XML já salvo
 *   no celular (Etapa 1 — é o fluxo a ser usado primeiro, conforme pedido)
 */
@Composable
fun HomeScreen(
    onLerViaCameraClick: () -> Unit,
    onCarregarXmlLocalClick: () -> Unit,
    onVerEstoqueClick: () -> Unit,
    onVerHistoricoClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Estoque Inteligente", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(32.dp))

        Button(
            onClick = onCarregarXmlLocalClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ler NF-e (arquivo XML local)")
        }

        Spacer(Modifier.height(12.dp))

        OutlinedButton(
            onClick = onLerViaCameraClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ler NF-e (câmera / QR Code)")
        }

        Spacer(Modifier.height(32.dp))

        TextButton(onClick = onVerEstoqueClick) { Text("Ver estoque") }
        TextButton(onClick = onVerHistoricoClick) { Text("Ver histórico de movimentações") }
    }
}
