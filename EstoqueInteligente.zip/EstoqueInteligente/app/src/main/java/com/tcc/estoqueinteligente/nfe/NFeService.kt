package com.tcc.estoqueinteligente.nfe

import android.content.Context
import android.net.Uri
import com.tcc.estoqueinteligente.data.model.NotaFiscal

/**
 * Resultado da tentativa de obter uma NF-e a partir de uma chave de acesso ou de um XML.
 */
sealed class ResultadoNFe {
    data class Sucesso(val notaFiscal: NotaFiscal) : ResultadoNFe()
    data class Erro(val mensagem: String) : ResultadoNFe()
}

/**
 * Contrato único que o resto do app usa para "obter uma NF-e".
 * A tela de leitura/conferência nunca fala diretamente com XML, arquivo ou API:
 * ela sempre chama NFeService.obterNotaFiscal(...).
 *
 * Isso permite trocar a fonte de dados (arquivo local -> API autorizada) sem
 * alterar nenhuma tela.
 */
interface NFeService {
    /**
     * @param chaveAcesso chave de 44 dígitos lida do QR Code/código de barras da NF-e.
     */
    suspend fun obterNotaFiscalPorChave(chaveAcesso: String): ResultadoNFe

    /**
     * Usado na Etapa 1 do desenvolvimento: ler um XML de NF-e já salvo no celular,
     * sem depender de leitura de câmera nem de rede.
     */
    suspend fun obterNotaFiscalPorArquivoLocal(context: Context, uriDoArquivo: Uri): ResultadoNFe
}

/**
 * Implementação usada nas Etapas 1 e 2: lê o XML de um arquivo local no celular.
 * Não faz nenhuma chamada de rede e não inventa dados de nenhuma NF-e.
 *
 * Quando a chave de acesso é lida pela câmera (Etapa 2) mas o XML correspondente
 * ainda não existe localmente, obterNotaFiscalPorChave retorna Erro, pois este app
 * NUNca deve simular ou inventar um XML de NF-e.
 */
class NFeServiceLocalXml(private val parser: NFeXmlParser = NFeXmlParser()) : NFeService {

    override suspend fun obterNotaFiscalPorChave(chaveAcesso: String): ResultadoNFe {
        return ResultadoNFe.Erro(
            "Nenhuma fonte de dados autorizada configurada ainda para consultar a chave " +
                "$chaveAcesso automaticamente. Selecione o arquivo XML correspondente " +
                "manualmente, ou aguarde a integração com a API oficial (ver NFeServiceApi)."
        )
    }

    override suspend fun obterNotaFiscalPorArquivoLocal(context: Context, uriDoArquivo: Uri): ResultadoNFe {
        return try {
            context.contentResolver.openInputStream(uriDoArquivo)?.use { stream ->
                val notaFiscal = parser.parse(stream)
                ResultadoNFe.Sucesso(notaFiscal)
            } ?: ResultadoNFe.Erro("Não foi possível abrir o arquivo selecionado.")
        } catch (e: Exception) {
            ResultadoNFe.Erro("Falha ao ler o XML da NF-e: ${e.message}")
        }
    }
}

/**
 * ============================================================================
 *  PONTO DE EXTENSÃO PARA A ETAPA 3 (API/serviço autorizado)
 * ============================================================================
 *
 * Quando você tiver uma API/integração autorizada para consultar NF-e pela chave
 * de acesso (por exemplo, um provedor homologado, ou uma API própria da empresa
 * que já tem certificado digital e convênio com a SEFAZ), implemente esta classe.
 *
 * NÃO faça requisições diretas à SEFAZ a partir do app — isso normalmente exige
 * certificado digital A1/A3 e não é permitido sem autorização/homologação.
 *
 * PASSO A PASSO para ativar:
 *   1. Preencha BASE_URL com a URL da API autorizada.
 *   2. Coloque a credencial (API key / token) em API_KEY.
 *      -> Nunca deixe a chave real hardcoded aqui em produção: use
 *         local.properties + BuildConfig, ou um cofre de segredos (ex: Android Keystore,
 *         variáveis de ambiente do CI). O campo abaixo é só o "onde plugar" durante o TCC.
 *   3. Implemente a chamada HTTP (ex: usando Retrofit ou OkHttp) dentro de
 *      obterNotaFiscalPorChave, convertendo a resposta da API para o objeto NotaFiscal.
 *   4. Em MainActivity/NFeServiceProvider, troque NFeServiceLocalXml por NFeServiceApi.
 */
class NFeServiceApi(
    private val context: Context,
    private val parser: NFeXmlParser = NFeXmlParser()
) : NFeService {

    companion object {
        // TODO(API-AUTORIZADA): preencher quando houver integração autorizada.
        private const val BASE_URL = "" // ex: "https://api.provedor-nfe-autorizado.com.br/v1"
        private const val API_KEY = ""  // ex: carregar de BuildConfig.NFE_API_KEY
    }

    override suspend fun obterNotaFiscalPorChave(chaveAcesso: String): ResultadoNFe {
        if (BASE_URL.isBlank() || API_KEY.isBlank()) {
            return ResultadoNFe.Erro(
                "API de NF-e ainda não configurada. Preencha BASE_URL e API_KEY em NFeServiceApi."
            )
        }
        // TODO(API-AUTORIZADA): implementar chamada HTTP real aqui (ex: Retrofit/OkHttp),
        // enviando a chaveAcesso e o cabeçalho de autenticação com API_KEY, e então
        // usar/adaptar `parser` (ou o parser de JSON da própria API) para montar o NotaFiscal.
        return ResultadoNFe.Erro("Chamada à API autorizada ainda não implementada.")
    }

    override suspend fun obterNotaFiscalPorArquivoLocal(context: Context, uriDoArquivo: Uri): ResultadoNFe {
        // Reaproveita a leitura local mesmo quando a API estiver ativa,
        // útil para testes durante a demonstração do TCC.
        return NFeServiceLocalXml(parser).obterNotaFiscalPorArquivoLocal(context, uriDoArquivo)
    }
}

/**
 * Único lugar do app que decide qual implementação de NFeService está ativa.
 * Para trocar de fonte de dados, mude apenas a linha abaixo.
 */
object NFeServiceProvider {
    fun get(context: Context): NFeService {
        // Etapas 1 e 2 do desenvolvimento: usar a versão local.
        return NFeServiceLocalXml()

        // Quando a Etapa 3 estiver pronta (API autorizada configurada em NFeServiceApi),
        // troque a linha acima por:
        // return NFeServiceApi(context)
    }
}
