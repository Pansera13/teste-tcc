package com.tcc.estoqueinteligente.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Estrutura preparada para as funcionalidades futuras de controle de lote,
 * validade e FEFO (Etapa 14). Ainda não é usada ativamente no fluxo principal,
 * mas já existe no banco para facilitar a expansão sem migrações complexas depois.
 */
@Entity(tableName = "lotes")
data class Lote(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val produtoId: Long,
    val numeroLote: String,
    val quantidade: Double,
    val dataValidadeEpochMillis: Long? = null
)
