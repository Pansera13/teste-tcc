package com.tcc.estoqueinteligente.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tcc.estoqueinteligente.data.model.NotaFiscal
import com.tcc.estoqueinteligente.data.model.ProdutoNFe
import java.text.NumberFormat
import java.util.Locale

/**
 * Tela de conferência (Etapa 9). Mostra os dados extraídos do XML e permite
 * editar quantidade/descrição de cada produto antes de confirmar a entrada no estoque.
 */
@Composable
fun ConferenciaScreen(
    notaFiscal: NotaFiscal,
    onConfirmar: (NotaFiscal) -> Unit,
    onCancelar: () -> Unit
) {
    // Cópia local editável dos produtos, para permitir edição de quantidade/descrição
    var produtosEditaveis by remember {
        mutableStateOf(notaFiscal.produtos.map { it.copy() })
    }
    val formatoMoeda = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("NF-e #${notaFiscal.numero}", style = MaterialTheme.typography.titleLarge)
        Text("Fornecedor: ${notaFiscal.fornecedorNome}", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))

        LazyColumn(Modifier.weight(1f)) {
            items(produtosEditaveis.size) { indice ->
                val item = produtosEditaveis[indice]
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        OutlinedTextField(
                            value = item.descricao,
                            onValueChange = { novoTexto ->
                                produtosEditaveis = produtosEditaveis.toMutableList().also {
                                    it[indice] = item.copy(descricao = novoTexto)
                                }
                            },
                            label = { Text("Produto") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = item.quantidade.toString(),
                            onValueChange = { novoTexto ->
                                val novaQuantidade = novoTexto.toDoubleOrNull() ?: item.quantidade
                                produtosEditaveis = produtosEditaveis.toMutableList().also {
                                    it[indice] = item.copy(quantidade = novaQuantidade)
                                }
                            },
                            label = { Text("Quantidade (${item.unidadeComercial})") },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = KeyboardType.Decimal
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(formatoMoeda.format(item.valorUnitario) + " / unid.")
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            OutlinedButton(onClick = onCancelar) { Text("Cancelar") }
            Button(onClick = {
                onConfirmar(notaFiscal.copy(produtos = produtosEditaveis))
            }) { Text("Confirmar entrada no estoque") }
        }
    }
}
