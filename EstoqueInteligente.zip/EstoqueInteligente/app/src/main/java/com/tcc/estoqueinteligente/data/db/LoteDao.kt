package com.tcc.estoqueinteligente.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.tcc.estoqueinteligente.data.model.Lote

@Dao
interface LoteDao {

    @Query("SELECT * FROM lotes WHERE produtoId = :produtoId ORDER BY dataValidadeEpochMillis ASC")
    suspend fun listarPorProduto(produtoId: Long): List<Lote>

    @Insert
    suspend fun inserir(lote: Lote): Long
}
