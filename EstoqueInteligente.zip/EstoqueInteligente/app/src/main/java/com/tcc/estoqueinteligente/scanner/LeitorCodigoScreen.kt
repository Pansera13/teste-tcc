package com.tcc.estoqueinteligente.scanner

import android.Manifest
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

/**
 * Tela de câmera para leitura de código de barras e QR Code (Etapa 2/3).
 * Reconhece a chave de acesso da NF-e (44 dígitos) tanto em QR Code quanto em
 * código de barras (linear), e valida usando validarChaveNFe.
 *
 * Uso: abrir esta tela a partir do botão "Ler NF-e" da tela inicial.
 * Ao detectar uma chave válida, chama onChaveLida(chave) uma única vez.
 */
@Composable
fun LeitorCodigoScreen(onChaveLida: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var temPermissaoCamera by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var jaProcessou by remember { mutableStateOf(false) }

    if (!temPermissaoCamera) {
        // Em uma implementação completa, dispare aqui um ActivityResultContracts.RequestPermission()
        // a partir da Activity/host que chama este composable.
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Permissão de câmera necessária para ler a NF-e.")
        }
        return
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            val executor = Executors.newSingleThreadExecutor()
            val scanner = BarcodeScanning.getClient()

            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                analysis.setAnalyzer(executor) { imageProxy ->
                    val mediaImage = imageProxy.image
                    if (mediaImage != null && !jaProcessou) {
                        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                        scanner.process(inputImage)
                            .addOnSuccessListener { codigos: List<Barcode> ->
                                for (codigo in codigos) {
                                    val valor = codigo.rawValue ?: continue
                                    val chave = extrairChaveNFeDoConteudo(valor)
                                    if (chave != null && !jaProcessou) {
                                        jaProcessou = true
                                        onChaveLida(chave)
                                    }
                                }
                            }
                            .addOnCompleteListener { imageProxy.close() }
                    } else {
                        imageProxy.close()
                    }
                }

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    analysis
                )
            }, ContextCompat.getMainExecutor(ctx))

            previewView
        }
    )
}

/**
 * O QR Code da NF-e normalmente é uma URL de consulta contendo a chave de 44 dígitos
 * (ex: "https://www.sefaz.../consulta?p=43240512345...|2|1|1|..."). O código de barras
 * (linear) costuma trazer só os 44 dígitos diretamente.
 * Esta função extrai os 44 dígitos de qualquer um dos dois formatos.
 */
fun extrairChaveNFeDoConteudo(conteudo: String): String? {
    val somenteNumeros = conteudo.filter { it.isDigit() }
    // Procura a primeira sequência de 44 dígitos consecutivos dentro do texto lido.
    val regex = Regex("\\d{44}")
    val encontrado = regex.find(somenteNumeros) ?: regex.find(conteudo)
    return encontrado?.value
}
